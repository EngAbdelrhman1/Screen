package com.example.screencopy

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Region
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Shows the screenshot with a dimmed overlay and a movable / resizable selection rectangle. */
class SelectionView(context: Context, private val bitmap: Bitmap) : View(context) {

    private val rect = RectF()
    private val dst = RectF()
    private val dim = Paint().apply { color = 0x99000000.toInt() }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = context.dp(2).toFloat()
    }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1E88E5.toInt() }
    private val handleR = context.dp(7).toFloat()
    private val slop = context.dp(36).toFloat()

    private var mode = 0 // 1 = new, 2 = move, 3 = resize
    private var l = false
    private var t = false
    private var r = false
    private var b = false
    private var lastX = 0f
    private var lastY = 0f
    private var anchorX = 0f
    private var anchorY = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (rect.isEmpty) rect.set(w * 0.15f, h * 0.30f, w * 0.85f, h * 0.65f)
    }

    override fun onDraw(canvas: Canvas) {
        dst.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawBitmap(bitmap, null, dst, null)
        canvas.save()
        @Suppress("DEPRECATION")
        canvas.clipRect(rect, Region.Op.DIFFERENCE)
        canvas.drawRect(dst, dim)
        canvas.restore()
        canvas.drawRect(rect, border)
        val cx = rect.centerX()
        val cy = rect.centerY()
        for (p in listOf(
            rect.left to rect.top, rect.right to rect.top,
            rect.left to rect.bottom, rect.right to rect.bottom,
            cx to rect.top, cx to rect.bottom,
            rect.left to cy, rect.right to cy
        )) canvas.drawCircle(p.first, p.second, handleR, handle)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x.coerceIn(0f, width.toFloat())
        val y = e.y.coerceIn(0f, height.toFloat())
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val inY = y > rect.top - slop && y < rect.bottom + slop
                val inX = x > rect.left - slop && x < rect.right + slop
                l = abs(x - rect.left) < slop && inY
                r = abs(x - rect.right) < slop && inY
                t = abs(y - rect.top) < slop && inX
                b = abs(y - rect.bottom) < slop && inX
                mode = when {
                    l || r || t || b -> 3
                    rect.contains(x, y) -> 2
                    else -> {
                        anchorX = x
                        anchorY = y
                        rect.set(x, y, x, y)
                        1
                    }
                }
                lastX = x
                lastY = y
            }
            MotionEvent.ACTION_MOVE -> {
                when (mode) {
                    1 -> rect.set(min(anchorX, x), min(anchorY, y), max(anchorX, x), max(anchorY, y))
                    2 -> {
                        val dx = (x - lastX).coerceIn(-rect.left, width - rect.right)
                        val dy = (y - lastY).coerceIn(-rect.top, height - rect.bottom)
                        rect.offset(dx, dy)
                    }
                    3 -> {
                        if (l) rect.left = x
                        if (r) rect.right = x
                        if (t) rect.top = y
                        if (b) rect.bottom = y
                        if (rect.left > rect.right) {
                            val tmp = rect.left; rect.left = rect.right; rect.right = tmp
                            val f = l; l = r; r = f
                        }
                        if (rect.top > rect.bottom) {
                            val tmp = rect.top; rect.top = rect.bottom; rect.bottom = tmp
                            val f = t; t = b; b = f
                        }
                    }
                }
                lastX = x
                lastY = y
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }

    /** Returns the selected part of the screenshot as a new bitmap. */
    fun cropSelection(): Bitmap? {
        if (width == 0 || height == 0) return null
        val sx = bitmap.width / width.toFloat()
        val sy = bitmap.height / height.toFloat()
        val x = (rect.left * sx).toInt().coerceIn(0, bitmap.width - 1)
        val y = (rect.top * sy).toInt().coerceIn(0, bitmap.height - 1)
        val w = (rect.width() * sx).toInt().coerceIn(1, bitmap.width - x)
        val h = (rect.height() * sy).toInt().coerceIn(1, bitmap.height - y)
        return Bitmap.createBitmap(bitmap, x, y, w, h)
    }
}
