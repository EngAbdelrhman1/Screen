package com.example.screencopy

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val reqCapture = 1001
    private val reqOverlay = 1002
    private val reqNotif = 1003
    private val reqStorage = 1004
    private var askedNotif = false
    private var askedStorage = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        val title = TextView(this).apply {
            text = "ScreenCopy"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
        }
        val desc = TextView(this).apply {
            text = "أيقونة عائمة: اضغط عليها لالتقاط الشاشة، حدّد الجزء، ثم احفظه أو انسخه للحافظة مباشرة.\n\n" +
                "ملاحظة: عند ظهور نافذة المشاركة اختر «الشاشة بالكامل»."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(16), 0, dp(24))
        }
        val btn = Button(this).apply {
            text = "تشغيل الأيقونة العائمة"
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(0xFF1E88E5.toInt())
            }
            setOnClickListener { startFlow() }
        }
        root.addView(title)
        root.addView(desc)
        root.addView(
            btn,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
        )
        setContentView(root)
    }

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات الأخرى» ثم ارجع", Toast.LENGTH_LONG).show()
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                reqOverlay
            )
            return
        }
        if (Build.VERSION.SDK_INT <= 28 && !askedStorage &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            askedStorage = true
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), reqStorage)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqNotif || requestCode == reqStorage) startFlow()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            reqOverlay -> if (Settings.canDrawOverlays(this)) startFlow()
            reqCapture -> {
                if (resultCode == RESULT_OK && data != null) {
                    val i = Intent(this, CaptureService::class.java)
                        .putExtra(CaptureService.EXTRA_CODE, resultCode)
                        .putExtra(CaptureService.EXTRA_DATA, data)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    finish()
                } else {
                    Toast.makeText(this, "تم رفض إذن التقاط الشاشة", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
